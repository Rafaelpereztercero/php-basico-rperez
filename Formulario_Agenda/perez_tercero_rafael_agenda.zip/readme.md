**NO SE HA OMITIDO NINGUN APARTADO**

Link directo : moodle.rperez.randion.es/agenda.php

Subida al github: https://github.com/DAW-presencial/php-basico-Rafaelpereztercero/blob/main/Formulario_Agenda/readme.md
![image](https://user-images.githubusercontent.com/91564342/197628894-bdd5fbf3-5c73-464f-a6b5-9d78f200f4f0.png)

